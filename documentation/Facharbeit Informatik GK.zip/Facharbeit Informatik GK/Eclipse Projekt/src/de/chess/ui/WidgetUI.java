package de.chess.ui;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.RoundRectangle2D;

import de.chess.game.Board;
import de.chess.game.PieceCode;
import de.chess.main.Constants;
import de.chess.util.MathUtil;

public class WidgetUI {
	
	private static final int WIDGET_WIDTH = 80;
	
	private static float switchHoverState;
	
	private static float prediction = 0.5f;
	
	private static float lerpedPrediction = prediction;
	
	public static void drawWidgets(Graphics2D graphics, Board b) {
		drawSwitchButton(graphics, b);
		
		drawPredictionBar(graphics);
	}
	
	private static void drawSwitchButton(Graphics2D graphics, Board b) {
		switchHoverState = MathUtil.lerp(switchHoverState, isHoveringSwitchButton(UIManager.getMouseX(), UIManager.getMouseY(), UIManager.getWidth(), UIManager.getHeight()) ? 1 : 0, 0.5f);
		
		int j = (int) (255 - 32 * switchHoverState);
		
		graphics.setColor(new Color(j, j, j));
		
		int side = (BoardUI.getHumanSide() + 1) % 2;
		
		int x = UIManager.getWidth() / 2 - 512 / 2 - 32 - 24 - WIDGET_WIDTH;
		int y = UIManager.getHeight() / 2 + 512 / 2 + 32 - WIDGET_WIDTH;
		
		graphics.fillRoundRect(x, y, WIDGET_WIDTH, WIDGET_WIDTH, 20, 20);
		
		graphics.drawImage(PieceCode.getSprite(PieceCode.getSpriteCode(side, PieceCode.KING)), x + WIDGET_WIDTH / 2 - 32, y + WIDGET_WIDTH / 2 - 32 - 1, null);
	}
	
	private static void drawPredictionBar(Graphics2D graphics) {
		lerpedPrediction = MathUtil.lerp(lerpedPrediction, prediction, 0.125f);
		
		int o = 16;
		
		int w = 24;
		
		int x = UIManager.getWidth() / 2 - 512 / 2 - 32 - 24 - w - o;
		int y = UIManager.getHeight() / 2 - 512 / 2 - 32 + o;
		
		int height = (512 + 64) - WIDGET_WIDTH - 24 - o * 2;
		
		graphics.setColor(Constants.COLOR_WHITE);
		graphics.fillRoundRect(x - o, y - o, w + o * 2, height + o * 2, 20, 20);
		
		float h = height * lerpedPrediction;
		float start = 0;
		
		if(BoardUI.getHumanSide() == PieceCode.BLACK) {
			start = h;
			
			h = height - h;
		}
		
		graphics.setColor(Constants.COLOR_BLACK);
		graphics.fill(new RoundRectangle2D.Float(x, y + start, w, h, 10, 10));
	}
	
	public static boolean isHoveringSwitchButton(int mx, int my, int width, int height) {
		int x = UIManager.getWidth() / 2 - 512 / 2 - 64 - WIDGET_WIDTH;
		int y = UIManager.getHeight() / 2 + 512 / 2 + 32 - WIDGET_WIDTH;
		
		x = mx - x;
		y = my - y;
		
		return x >= 0 && y>= 0 && x < WIDGET_WIDTH && y < WIDGET_WIDTH;
	}
	
	public static void setPrediction(int i) {
		int range = 350;
		
		float f = (float) (i + range) / (range * 2);
		
		if(f > 1) f = 1;
		else if(f < 0) f = 0;
		
		prediction = f;
	}
	
}
