package de.chess.game;

public class BoardSquare {
	
	public static final int NONE = -1;
	
}
